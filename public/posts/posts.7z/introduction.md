---
title: "Introduction"
date: 2023-08-15T15:26:30+02:00
draft: false
weight: 1
---

**ASN19434** is a personal ASN which was established by me in August 1, 2023 with help from [Cloudie](https://cloudie.sh/) and his partner [Zappie Host LLC](https://zappiehost.com) 🌐

It's main goal is to build own networks with BGP which are routable over the internet. The network is dedicated for education and learning. 
